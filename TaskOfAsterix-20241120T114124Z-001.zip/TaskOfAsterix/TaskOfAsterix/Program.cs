﻿using System;
using TaskOfAsterix;



/*string a1 = Basix.PrintNumbers(2);   // a1 == "1 2"
string a2 = Basix.PrintNumbers(6);   // a2 == "1 2 3 4 5 6"

Console.WriteLine(a1);
Console.WriteLine(a2);

int b1 = Basix.Fibonacci(0);    // b1 == 0
int b2 = Basix.Fibonacci(1);    // b2 == 1
int b3 = Basix.Fibonacci(10);   // b3 == 55

Console.WriteLine(b1);
Console.WriteLine(b2);
Console.WriteLine(b3);

int c1 = Basix.Factorial(0);    // c1 == 1
int c2 = Basix.Factorial(5);    // c2 == 120
int c3 = Basix.Factorial(10);   // c3 == 3628800
Console.WriteLine(c1);
Console.WriteLine(c2);
Console.WriteLine(c3);


float d1 = Basix.MyPow(0, 2);    // d1 == 0f
float d2 = Basix.MyPow(2, 0);    // d2 == 1f
float d3 = Basix.MyPow(0, 0);    // d3 == 1f
float d4 = Basix.MyPow(10, 2);   // d4 == 100f
float d5 = Basix.MyPow(-8, 3);   // d5 == -512f
float d6 = Basix.MyPow(2, -5);   // d6 == 0.03125f
Console.WriteLine(d1);
Console.WriteLine(d2);
Console.WriteLine(d3);
Console.WriteLine(d4);
Console.WriteLine(d5);
Console.WriteLine(d6);

string e1 = Basix.ReverseString("");             // e1 == ""
string e2 = Basix.ReverseString("Caesar");       // e2 == "raseaC"
string e3 = Basix.ReverseString("a");            // e3 == "a"
string e4 = Basix.ReverseString("123456789");    // e4 == "987654321"
Console.WriteLine(e1);
Console.WriteLine(e2);
Console.WriteLine(e3);
Console.WriteLine(e4);

bool f1 = Basix.SearchLetter("Caesar", 'a');      // f1 == true
bool f2 = Basix.SearchLetter("Caesar", 'S');      // f2 == false
bool f3 = Basix.SearchLetter("Caesar", 'u');      // f3 == false
bool f4 = Basix.SearchLetter("Asterix", 'A');   // f4 == true
bool f5 = Basix.SearchLetter("ASTERIX", 'a');   // f5 == false
Console.WriteLine(f1);
Console.WriteLine(f2);
Console.WriteLine(f3);
Console.WriteLine(f4);
Console.WriteLine(f5);*/


/*string g1 = RomeTasks.CaeserGame(6);    // g1 == "1 2 Julius 4 Caesar Julius"
string g2 = RomeTasks.CaeserGame(20);   // g2 == "1 2 Julius 4 Caesar Julius 7 8 Julius Caesar 11 Julius 13 14 Julius Caesar 16 17 Julius 19 Caesar"
Console.WriteLine(g1);
Console.WriteLine(g2);

bool h1 = RomeTasks.IsPalindrome("ACDC");                           // h1 == false
bool h2 = RomeTasks.IsPalindrome("12321");                          // h2 == true
bool h3 = RomeTasks.IsPalindrome("kayak");                          // h3 == true
bool h4 = RomeTasks.IsPalindrome("A man, a plan, a canal Panama");  // h4 == true
Console.WriteLine(h1);
Console.WriteLine(h2);
Console.WriteLine(h3);
Console.WriteLine(h4);

int i1 = RomeTasks.ReverseNumber(0);      // i1 == 0
int i2 = RomeTasks.ReverseNumber(123);    // i2 == 321
int i3 = RomeTasks.ReverseNumber(-123);   // i3 == -321
Console.WriteLine(i1);
Console.WriteLine(i2);
Console.WriteLine(i3);

int j1 = RomeTasks.GCD(30, 20);    // j1 == 10
int j2 = RomeTasks.GCD(18, -8);    // j2 == 2
int j3 = RomeTasks.GCD(-24, 4);    // j3 == 4
int j4 = RomeTasks.GCD(-10, -5);   // j4 == 5
int j5 = RomeTasks.GCD(0, 42);     // j5 == 42
Console.WriteLine(j1);
Console.WriteLine(j2);
Console.WriteLine(j3);
Console.WriteLine(j4);
Console.WriteLine(j5);

bool k1 = RomeTasks.CheckPrime(1);      // k1 == false
bool k2 = RomeTasks.CheckPrime(7);      // k2 == true
bool k3 = RomeTasks.CheckPrime(47);     // k3 == true
bool k4 = RomeTasks.CheckPrime(48);     // k4 == false
bool k5 = RomeTasks.CheckPrime(666);    // k5 == false
bool k6 = RomeTasks.CheckPrime(-5);     // k6 == false
Console.WriteLine(k1);
Console.WriteLine(k2);
Console.WriteLine(k3);
Console.WriteLine(k4);
Console.WriteLine(k5);
Console.WriteLine(k6);*/

string l1 = Circus.Tree('*', 4);   // l1 == "   *\n  ***\n *****\n*******\n  ***\n  ***"
string l2 = Circus.Tree('*', 7);   // l2 == "      *\n     ***\n    *****\n   *******\n  *********\n ***********\n*************\n     ***\n     ***"
System.Console.Write(l2);

int m1 = Circus.KingOfTheHill("1 1 1");                 // m1 == 1
int m2 = Circus.KingOfTheHill("0 1 2 2 4 5 5 7 7");     // m2 == 7
int m3 = Circus.KingOfTheHill("9 9 9 7 5 3 2 1 0");     // m3 == 9
int m4 = Circus.KingOfTheHill("1 3 4 6 8 9 7 5 3 0");   // m4 == 9 
int m5 = Circus.KingOfTheHill("1 2 3 2 1 2 5 5 1");     // m5 == -1
int m6 = Circus.KingOfTheHill("");                      // m6 == -1
Console.WriteLine(m1);
Console.WriteLine(m2);
Console.WriteLine(m3);
Console.WriteLine(m4);
Console.WriteLine(m5);
Console.WriteLine(m6);


string n1 = Circus.ItoA(0);      // n1 == "0"
string n2 = Circus.ItoA(123);    // n2 == "123"
string n3 = Circus.ItoA(-123);   // n3 == "-123"
Console.WriteLine(n1);
Console.WriteLine(n2);
Console.WriteLine(n3);

int o1 = Circus.AtoI("123");     // o1 == 123
int o2 = Circus.AtoI("+123");    // o2 == 123
int o3 = Circus.AtoI("-123");    // o3 == -123
int o4 = Circus.AtoI("+010");    // o4 == 10
Console.WriteLine(o1);
Console.WriteLine(o2);
Console.WriteLine(o3);
Console.WriteLine(o4);

string p1 = Circus.DecimalToBase16(42);      // p1 == "2A"
string p2 = Circus.DecimalToBase16(0);       // p2 == "0"
string p3 = Circus.DecimalToBase16(27972);   // p3 == "6D44"
Console.WriteLine(p1);
Console.WriteLine(p2);
Console.WriteLine(p3);

int q1 = Circus.Base16ToDecimal("2A");     // q1 == 42
int q2 = Circus.Base16ToDecimal("0");      // q2 == 0
int q3 = Circus.Base16ToDecimal("6D44");   // q3 == 27972

Console.WriteLine(q1);
Console.WriteLine(q2);
Console.WriteLine(q3);

string r1 = Circus.CaesarTower(1);   // r1 == "Moves for 1 disks\n1 -> 3"
string r2 = Circus.CaesarTower(3);   // r2 == "Moves for 3 disks\n1 -> 3\n1 -> 2\n3 -> 2\n1 -> 3\n2 -> 1\n2 -> 3\n1 -> 3"
System.Console.Write(r2);
