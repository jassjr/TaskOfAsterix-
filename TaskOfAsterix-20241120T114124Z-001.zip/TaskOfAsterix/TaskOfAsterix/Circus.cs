﻿namespace TaskOfAsterix;

public class Circus
{
    public static string Tree(char c, int n)
    {
        if (n < 4)
        {
            throw new ArgumentException("n must be at least 4");
        }
        
        string s = ""; // ethe main string use kita 
        
        for (int a = 1; a <= n; a++) // fir main int kita 
        { 
            for (int p = 0; p < n - a; p++) // fir main int kita p 
                s += " ";

            for (int p = 0; p < 2 * a - 1; p++) // for int karna 
                s += c;

            s += "\n";
        }

        int ls = 3; // int ls 
        int vt = 2; // int vt 
        for (int a = 0; a < vt; a++) // for int a 
        {
            for (int p = 0; p < n - ls / 2 - 1; p++) // fir main for int kita 
                s += " "; // fir ethe s use kita 

            for (int p = 0; p < ls; p++) //fir int kita 
                s += c; // s use kita 

            s += "\n"; // fir s and n use kita 
        } 

        return s; // fir rt it 
    }
     
    public static int KingOfTheHill(string s)
    {
        if (string.IsNullOrWhiteSpace(s))
            return -1;

        int x = s[0] - '0'; int v = x; // ethe main int kita x teh v nal
        bool g = false; bool at = false; // ethe main false kita bool deh nal

        for (int i = 2; i < s.Length; i += 2) // ethe main for kita 
        { 
            int c = s[i] - '0'; // fir int 
            if (c > v) // ethe main c vada teh v chota
            {
                if (g) return -1; g = true; // ethe main return kita fir main true vekhya
            }
            else if (c < v) // c chota teh v vadda
            {
                if (!g) return -1; g = true; // ethe main return kita fir main true vekhya
            }
            else
            {
                if (at) return -1; at = true; // ethe main return kita fir main true vekhya
            }

            if (c > x) x = c; 
            v = c;
        }

        return x; // fir return kita 
    }

    public static string ItoA(int n)
    {
        if (n == 0)
        {
            return "0";
        }
        
        string a = "";
        bool lv = n < 0; // ethe main bool paya 
        if (lv) // fir main if kita 
        {
            n = -n;
        }

        while (n > 0) // fir main while kita 
        {
            a = (char)('0' + n % 10) + a;
            n /= 10; // fir n kita 
        }

        return lv ? "-" + a : a; // rt it 
    }

    public static int AtoI(string s)
    {
        if (string.IsNullOrEmpty(s))
            throw new ArgumentException("ls"); // invalid argument dehda

        int st = 0, t = 0; // ethe main int kita
        bool jv = s[0] == '-'; // ethe bool veh
        if (s[0] == '+' || s[0] == '-')
            st++;

        for (int a = st; a < s.Length; a++)
        {
            if (s[a] < '0' || s[a] > '9') // ethe main if kita
                throw new ArgumentException("ls"); // invalid argument dehda

            t = t * 10 + (s[a] - '0'); // ethe main t*t nal kita
        }

        return jv ? -t : t; // ethe main return kita
    }

    public static string DecimalToBase16(ushort n)
    {
        if (n == 0)
            return "0"; // rt it 

        string t = ""; // ethe main string t 
        string cs = "0123456789ABCDEF"; // same ethe main string 
        while (n > 0) // fir main while kita 
        {
            t = cs[n % 16] + t; // main ehte t use kita 
            n /= 16; // fir n use kita 
        }

        return t; // fir rt it 
    }

    public static ushort Base16ToDecimal(string hexNumber)
    {
        ushort lt = 0;
        foreach (char p in hexNumber)
        {
            int s; // ethe int kita
            if (p >= '0' && p <= '9')
                s = p - '0';
            else if (p >= 'A' && p <= 'F') // ethe if else
                s = p - 'A' + 10; // ethe main +10 kita qui menu result mil sake
            else
                throw new ArgumentException("exe");

            lt = (ushort)(lt * 16 + s); // ethe main lt kita 
        }

        return lt; // ethe main lt kita 
    }

    public static string CaesarTower(int n)
    {
        if (n < 1)
        {
            throw new ArgumentException("exe"); // ethe main argument exeption use kita
        }

        string t = "Moves for " + n + " disks\n"; // ethe main string use kita si
        int mk = (1 << n) - 1; // ethe main move kita total 
        for (int ct = 1; ct <= mk; ct++) // ethe main chek kita num
        {
            int r = (ct & ct - 1) % 3 + 1;
            int to = ((ct | ct - 1) + 1) % 3 + 1; //ethe main chafe kite

            t += r + " -> " + to + "\n"; // ethe main fir mv 
        }
        return t.TrimEnd('\n'); // rt it 
    }
}
