﻿namespace TaskOfAsterix
{
   public class RomeTasks
   {
       
       //Ceasar Game 
       public static string CaeserGame(int n)
       {
           if (n < 1) throw new ArgumentException();
           string ls = "1"; // exception deh 
           for (int i = 2; i <= n; i++)
           
               if (i % 3 == 0 && i % 5 == 0) ls += " " + "Julius Caesar"; else if (i % 3 == 0) ls += " " + "Julius" ; else if (i % 5 == 0) ls += " " + "Caesar" ; else ls += " " + i;
            // ethe main if kita teh fir if tu bah main buhat kujh likhyea 
           return ls; // rt it 
       }
       
       // Palindrome
       public static bool IsPalindrome(string s)
       {
           string lv = s.ToLower(); return Reverse(Reverse(lv)) == Reverse(s).ToLower(); // ethe string teh return kita si palindrome fnction vaste 
       }

       //Reverse Number

       private static string Reverse(string b)
       { if (b == "")  return "";
           string p = ""; // ethe main string use kita si 
           foreach (char rj in b) // for each use karke fir main rj in b 
           if (rj == ' ' || rj == ',' || rj == '!' || rj == '?' || rj == ':' || rj== '.')  p = "" + p; // fir if kita si teh vadia hoya 
               else p = rj + p;
             return p;  } // rt it 


       public static int ReverseNumber(int n)
       { int rv = 0; // ethe main int kita si teh equal si 0 nal
           int ln = n < 0 ? -1 : 1;
           n = (n < 0) ? (n * -1) : n; // ethe main vekkhya ki n 0 tu chota si 
           int m = harjas (n, rv); // fir new int m karke harjas da nam likhta 
           return m * ln ; } // rt it 
       private static int harjas(int r, int j)
       { if (r == 0) return j; // ethe return kita si 
           while (r > 0) // fir while kita teh vekhya r chota veh 
            j = j * 10 + r % 10; // 10 karke function likh ti 
               r  = r / 10;
            return j; // rt it 
       }


       public static int GCD(int a, int b)
       { a = a < 0 ? -a : a; 
           b = b < 0 ? -b : b;
           while (b != 0) // ethe main while kita 
           { int terima = b; // ethe main int kita 
               b = a % b;
               a = terima ;// ethe main a nu variable deh ke terima 
           } return a; // rt it 
       }


       public static bool CheckPrime(int n)
       {
           if (n <= 1) // ethe main if kita 
            return false; // ethe return false kita 
           
           if (n == 2)// ethe main if kita{
               return true; // ethe return true kita }
          
           if (n % 2 == 0) // ethe main if kit
               return false; // ethe return false kita 
           
           for (int o = 3; o * o<= n;o+= 2) // ethe fir int kita nal for 
               
               if (n % o==0) //ethe main if kita 
                   
                   return false; // ethe main return false kita 

           return true; // return true kita main 
       }
   } }
