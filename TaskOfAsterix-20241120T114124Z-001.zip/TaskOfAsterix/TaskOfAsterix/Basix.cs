﻿namespace TaskOfAsterix;

public class Basix
{
    // Fonction NUMBERS    
    public static string PrintNumbers(int n)
    {
        if (n < 1)
        {
            throw new ArgumentException(" lower than 1."); // err
        }

        string st = "";
        int a = 1; // init
        while (a <= n)
        {
            st = st + a + " ";
            a = a + 1; // increm
        }
        return st; // return st
    }
    
    // Fonction FIBO       
    public static int Fibonacci(int n)
    {
        if (n < 0)
        {
            throw new ArgumentException(" not be negative."); // err
        }
        if (n == 0)
        {
            return 0; // return zero
        }
        if (n == 1)
        {
            return 1; // return one
        }
        
        int c = 1; // init
        int v = 0; // init
        int a = 0; // init
        int i = 2; // init

        while (i <= n)
        {
            a = c + v; // add
            v = c;
            c = a;
            i = (i + 1); // increm
        }

        return a; // return a
    }
    
    // Fonction FACTORIAL 
    public static int Factorial(int n)
    {
        if (n < 0)
        {
            throw new ArgumentException(" not be negative."); // err
        }

        int a = 1; // init
        for (int i = 1; i <= n; i++)
        {
            a *= i; // mult
        }
        return a; // return a
    }
    
    // Fonction MYPOW    
    public static float MyPow(int a, int b)
    {
        if (b == 0)
        {
            return 1f; // return if equal
        }
        if (a == 0 && b > 0)
        {
            return 0f; // return it
        }

        float fa = 1f; // init 
        int p = b; // init
        if (b < 0)
        {
            p = -b; // into pos
        }

        int i = 0; // init
        while (i < p)
        {
            fa *= a; // mult
            i = (i + 1); // increm
        }
        if (b < 0)
        {
            fa = 1f / fa; // divide
        }
        return fa; // return
    }

    // Fonction REVERSE    
    public static string ReverseString(string s)
    {
        string st = "";
        foreach (char c in s)
        {
            st = c + st; // add
        }

        return st; // return st
    }

    // Fonction SEARCH
    public static bool SearchLetter(string s, char c)
    {
        int a = 0; // init
        bool bl = false; // init to false
        while (a < s.Length && !bl)
        {
            if (s[a] == c)
            {
                bl = true; // true
            }
            a++; // increm
        }
        return bl; // return 
    }
}
    
